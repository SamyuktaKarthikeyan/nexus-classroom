package com.example.nexus.demo.enumerated;

public enum Role {
    USER,
    ADMIN,
    STAFF
}
