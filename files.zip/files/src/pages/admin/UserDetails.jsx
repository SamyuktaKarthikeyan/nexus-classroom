import React from 'react'

const UserDetails = () => {
  return (
    <div>UserDetails</div>
  )
}

export default UserDetails