import React from 'react'

const AddPlan = () => {
  return (
    <div>AddPlan</div>
  )
}

export default AddPlan