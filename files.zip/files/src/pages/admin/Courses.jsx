import CourseGallery from '../../components/CourseGallery'

const Courses = () => {
  return (
    <div className="p-20">
        <CourseGallery/>
    </div>
  )
}

export default Courses